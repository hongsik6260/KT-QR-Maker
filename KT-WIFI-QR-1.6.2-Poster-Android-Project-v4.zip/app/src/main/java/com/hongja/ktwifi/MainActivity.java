package com.hongja.ktwifi;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.ContentValues;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.Manifest;
import android.content.pm.PackageManager;
import android.webkit.*;
import android.util.Base64;
import android.widget.Toast;
import android.print.*;
import android.graphics.pdf.PdfDocument;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import org.json.*;
import java.io.*;

public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> chooser; Uri captureUri; static final int PICK=99;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);WebSettings s=web.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowFileAccessFromFileURLs(true);web.addJavascriptInterface(new Bridge(),"HongjaApp");web.addJavascriptInterface(new PosterBridge(),"AndroidPoster");web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){if(chooser!=null)chooser.onReceiveValue(null);chooser=cb;try{
          Intent pick=new Intent(Intent.ACTION_GET_CONTENT);pick.addCategory(Intent.CATEGORY_OPENABLE);pick.setType("image/*");
          Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
          ContentValues cv=new ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,"KT-WIFI-Camera-"+System.currentTimeMillis()+".jpg");cv.put(MediaStore.Images.Media.MIME_TYPE,"image/jpeg");
          captureUri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);
          if(captureUri!=null){camera.putExtra(MediaStore.EXTRA_OUTPUT,captureUri);camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);}
          Intent launch;
          if(p.isCaptureEnabled() && captureUri!=null){launch=camera;}
          else {launch=Intent.createChooser(pick,"사진 선택 또는 촬영");if(captureUri!=null)launch.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{camera});}
          startActivityForResult(launch,PICK);return true;
        }catch(Exception e){chooser.onReceiveValue(null);chooser=null;return false;}}});web.loadUrl("file:///android_asset/index.html");}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==PICK&&chooser!=null){Uri[] selected=WebChromeClient.FileChooserParams.parseResult(result,data);
      if(result==RESULT_OK && (selected==null || selected.length==0) && captureUri!=null)selected=new Uri[]{captureUri};
      chooser.onReceiveValue(selected);chooser=null;captureUri=null;}}
 void js(String script){runOnUiThread(()->web.evaluateJavascript(script,null));}
 byte[] bytes(String data){return Base64.decode(data.substring(data.indexOf(',')+1),Base64.DEFAULT);}
 void save(String data,String name,boolean share){try{byte[] raw=bytes(data);ContentValues v=new ContentValues();v.put(MediaStore.Images.Media.DISPLAY_NAME,name);v.put(MediaStore.Images.Media.MIME_TYPE,"image/png");if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/KT-WIFI-QR/");Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,v);if(uri==null)throw new IOException("이미지 생성 실패");try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(raw);}if(share){Intent i=new Intent(Intent.ACTION_SEND);i.setType("image/png");i.putExtra(Intent.EXTRA_STREAM,uri);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);runOnUiThread(()->startActivity(Intent.createChooser(i,"이미지 공유")));}else runOnUiThread(()->Toast.makeText(this,"사진에 저장 완료",Toast.LENGTH_SHORT).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"저장 실패: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
 class Bridge {
  @JavascriptInterface public void recognize(String data,int id,String target){try{byte[] raw=bytes(data);Bitmap bitmap=BitmapFactory.decodeByteArray(raw,0,raw.length);InputImage image=InputImage.fromBitmap(bitmap,0);TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(image).addOnSuccessListener(result->{try{JSONObject obj=new JSONObject();obj.put("id",id);JSONArray arr=new JSONArray();for(com.google.mlkit.vision.text.Text.TextBlock block:result.getTextBlocks()){for(com.google.mlkit.vision.text.Text.Line line:block.getLines()){JSONObject row=new JSONObject();row.put("text",line.getText());arr.put(row);}}obj.put("results",arr);js("window.hongjaOcrResult("+obj.toString()+")");}catch(Exception e){error(id,e.getMessage());}}).addOnFailureListener(e->error(id,e.getMessage()));}catch(Exception e){error(id,e.getMessage());}}
  void error(int id,String message){try{JSONObject j=new JSONObject();j.put("id",id);j.put("error",message);js("window.hongjaOcrResult("+j.toString()+")");}catch(Exception ignored){}}
  @JavascriptInterface public void image(String data,String action){new Thread(()->save(data,"KT-WIFI-QR-"+System.currentTimeMillis()+".png","share".equals(action))).start();}
  @JavascriptInterface public void bluetooth(String action,String options){try{JSONObject j=new JSONObject(options);JSONObject out=new JSONObject();out.put("id",j.optInt("id"));out.put("error","이 빌드에는 기존 블루투스 연결 브리지가 아직 통합되지 않았습니다.");js("window.hongjaBtEvent("+out.toString()+")");}catch(Exception ignored){}}
 }
 class PosterBridge {
  @JavascriptInterface public void savePng(String data,String name){new Thread(()->save(data,name,false)).start();}
  @JavascriptInterface public void savePdf(String data,String name){new Thread(()->{try{byte[] raw=bytes(data);Bitmap bmp=BitmapFactory.decodeByteArray(raw,0,raw.length);if(bmp==null)throw new IOException("이미지 읽기 실패");PdfDocument pdf=new PdfDocument();int w=595,h=842;PdfDocument.Page page=pdf.startPage(new PdfDocument.PageInfo.Builder(w,h,1).create());page.getCanvas().drawBitmap(bmp,null,new Rect(0,0,w,h),null);pdf.finishPage(page);ContentValues v=new ContentValues();v.put(MediaStore.MediaColumns.DISPLAY_NAME,name);v.put(MediaStore.MediaColumns.MIME_TYPE,"application/pdf");if(Build.VERSION.SDK_INT>=29)v.put(MediaStore.MediaColumns.RELATIVE_PATH,"Download/KT-WIFI-QR/");Uri uri=getContentResolver().insert(Build.VERSION.SDK_INT>=29?MediaStore.Downloads.EXTERNAL_CONTENT_URI:MediaStore.Files.getContentUri("external"),v);if(uri==null)throw new IOException("PDF 생성 실패");try(OutputStream out=getContentResolver().openOutputStream(uri)){pdf.writeTo(out);}pdf.close();runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF 저장 완료",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"PDF 저장 실패: "+e.getMessage(),Toast.LENGTH_LONG).show());}}).start();}
  @JavascriptInterface public void printPoster(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("KT WiFi 홍보물",web.createPrintDocumentAdapter("KT WiFi 홍보물"),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());});}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
