package com.hongja.ktwifipromo;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.util.Base64;import android.webkit.*;import android.view.*;import android.net.Uri;import java.io.*;import com.google.mlkit.vision.common.InputImage;import com.google.mlkit.vision.text.TextRecognition;import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);WebSettings st=web.getSettings();st.setJavaScriptEnabled(true);st.setDomStorageEnabled(true);st.setAllowFileAccess(true);web.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){fileCb=cb;try{startActivityForResult(p.createIntent(),100);return true;}catch(Exception e){fileCb=null;return false;}}});web.addJavascriptInterface(new Bridge(),"HongjaApp");web.loadUrl("file:///android_asset/index.html");}
 ValueCallback<Uri[]> fileCb;
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==100&&fileCb!=null){fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCb=null;}}
 void send(String js){runOnUiThread(()->web.evaluateJavascript(js,null));}
 String quote(String s){return org.json.JSONObject.quote(s);}
 public class Bridge {
 @JavascriptInterface public void recognize(String data,int id,String target){
  try {
   String raw=data.substring(data.indexOf(',')+1);
   byte[] bytes=Base64.decode(raw,Base64.DEFAULT);
   Bitmap original=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
   if(original==null)throw new Exception("이미지를 읽지 못했습니다.");
   int width=original.getWidth(),height=original.getHeight();
   if(width<1||height<1)throw new Exception("선택 영역이 비어 있습니다.");
   int scale=Math.max(1,Math.min(3,Math.min(2400/Math.max(1,width),1800/Math.max(1,height))));
   Bitmap enlarged=scale>1?Bitmap.createScaledBitmap(original,width*scale,height*scale,true):original;
   com.google.mlkit.vision.text.TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
   recognizer.process(InputImage.fromBitmap(enlarged,0)).addOnSuccessListener(first->{
    String text=first.getText();
    if(text!=null&&!text.trim().isEmpty()){
     send("window.hongjaOcrResult({id:"+id+",results:[{method:'ML Kit',confidence:90,text:"+quote(text)+"}]})");
     return;
    }
    try {
     Bitmap corrected=Bitmap.createBitmap(enlarged.getWidth(),enlarged.getHeight(),Bitmap.Config.ARGB_8888);
     int[] pixels=new int[enlarged.getWidth()*enlarged.getHeight()];
     enlarged.getPixels(pixels,0,enlarged.getWidth(),0,0,enlarged.getWidth(),enlarged.getHeight());
     for(int i=0;i<pixels.length;i++){
      int c=pixels[i];int gray=(android.graphics.Color.red(c)*299+android.graphics.Color.green(c)*587+android.graphics.Color.blue(c)*114)/1000;
      int value=gray<155?0:255;
      pixels[i]=android.graphics.Color.rgb(value,value,value);
     }
     corrected.setPixels(pixels,0,corrected.getWidth(),0,0,corrected.getWidth(),corrected.getHeight());
     recognizer.process(InputImage.fromBitmap(corrected,0)).addOnSuccessListener(second->{
      send("window.hongjaOcrResult({id:"+id+",results:[{method:'ML Kit 보정',confidence:80,text:"+quote(second.getText())+"}]})");
     }).addOnFailureListener(e->send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})"));
    }catch(Exception e){send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})");}
   }).addOnFailureListener(e->send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})"));
  }catch(Exception e){send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})");}
 }
 @JavascriptInterface public void image(String data,String action){try{String raw=data.substring(data.indexOf(',')+1);byte[] bytes=Base64.decode(raw,Base64.DEFAULT);File dir=getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES);if(dir==null)throw new Exception("저장 폴더를 찾지 못했습니다.");File f=new File(dir,"KT-WiFi-"+System.currentTimeMillis()+".png");try(FileOutputStream out=new FileOutputStream(f)){out.write(bytes);}runOnUiThread(()->new AlertDialog.Builder(MainActivity.this).setMessage("이미지 저장 완료: "+f.getAbsolutePath()).setPositiveButton("확인",null).show());}catch(Exception e){send("alert("+quote("이미지 저장 실패: "+e.getMessage())+")");}}
 }
}
