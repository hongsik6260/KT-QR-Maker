package com.hongja.ktwifipromo;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.*;import android.util.Base64;import android.webkit.*;import android.view.*;import android.net.Uri;import java.io.*;import com.google.mlkit.vision.common.InputImage;import com.google.mlkit.vision.text.TextRecognition;import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b){super.onCreate(b);web=new WebView(this);setContentView(web);WebSettings st=web.getSettings();st.setJavaScriptEnabled(true);st.setDomStorageEnabled(true);st.setAllowFileAccess(true);web.setWebChromeClient(new WebChromeClient(){public boolean onShowFileChooser(WebView v,ValueCallback<Uri[]> cb,FileChooserParams p){fileCb=cb;try{startActivityForResult(p.createIntent(),100);return true;}catch(Exception e){fileCb=null;return false;}}});web.addJavascriptInterface(new Bridge(),"HongjaApp");web.loadUrl("file:///android_asset/index.html");}
 ValueCallback<Uri[]> fileCb;
 @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==100&&fileCb!=null){fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCb=null;}}
 void send(String js){runOnUiThread(()->web.evaluateJavascript(js,null));}
 String quote(String s){return org.json.JSONObject.quote(s);}
 public class Bridge {
 @JavascriptInterface public void recognize(String data,int id,String target){
  try {
   String raw=data.substring(data.indexOf(',')+1);
   byte[] bytes=Base64.decode(raw,Base64.DEFAULT);
   Bitmap original=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
   if(original==null)throw new Exception("이미지를 읽지 못했습니다.");
   int width=original.getWidth(),height=original.getHeight();
   if(width<1||height<1)throw new Exception("선택 영역이 비어 있습니다.");
   int scale=Math.max(1,Math.min(3,Math.min(2400/Math.max(1,width),1800/Math.max(1,height))));
   Bitmap enlarged=scale>1?Bitmap.createScaledBitmap(original,width*scale,height*scale,true):original;
   com.google.mlkit.vision.text.TextRecognizer recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
   recognizer.process(InputImage.fromBitmap(enlarged,0)).addOnSuccessListener(first->{
    String text=first.getText();
    if(text!=null&&!text.trim().isEmpty()){
     send("window.hongjaOcrResult({id:"+id+",results:[{method:'ML Kit',confidence:90,text:"+quote(text)+"}]})");
     return;
    }
    try {
     Bitmap corrected=Bitmap.createBitmap(enlarged.getWidth(),enlarged.getHeight(),Bitmap.Config.ARGB_8888);
     int[] pixels=new int[enlarged.getWidth()*enlarged.getHeight()];
     enlarged.getPixels(pixels,0,enlarged.getWidth(),0,0,enlarged.getWidth(),enlarged.getHeight());
     for(int i=0;i<pixels.length;i++){
      int c=pixels[i];int gray=(android.graphics.Color.red(c)*299+android.graphics.Color.green(c)*587+android.graphics.Color.blue(c)*114)/1000;
      int value=gray<155?0:255;
      pixels[i]=android.graphics.Color.rgb(value,value,value);
     }
     corrected.setPixels(pixels,0,corrected.getWidth(),0,0,corrected.getWidth(),corrected.getHeight());
     recognizer.process(InputImage.fromBitmap(corrected,0)).addOnSuccessListener(second->{
      send("window.hongjaOcrResult({id:"+id+",results:[{method:'ML Kit 보정',confidence:80,text:"+quote(second.getText())+"}]})");
     }).addOnFailureListener(e->send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})"));
    }catch(Exception e){send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})");}
   }).addOnFailureListener(e->send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})"));
  }catch(Exception e){send("window.hongjaOcrResult({id:"+id+",error:"+quote(e.getMessage())+"})");}
 }

 void notifyUser(String msg){send("alert("+quote(msg)+")");}
 byte[] decodeImage(String data){return Base64.decode(data.substring(data.indexOf(',')+1),Base64.DEFAULT);}
 void saveBytes(byte[] bytes,String name,String mime,boolean pictures)throws Exception{
  if(android.os.Build.VERSION.SDK_INT>=29){
   android.content.ContentValues values=new android.content.ContentValues();
   values.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME,name);
   values.put(android.provider.MediaStore.MediaColumns.MIME_TYPE,mime);
   values.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH,(pictures?"Pictures/KT-WiFi/":"Download/KT-WiFi/"));
   android.net.Uri uri=getContentResolver().insert(pictures?android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI:android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI,values);
   if(uri==null)throw new Exception("저장 위치를 만들 수 없습니다.");
   try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new Exception("파일을 열 수 없습니다.");out.write(bytes);}
  }else{
   File dir=new File(getExternalFilesDir(pictures?android.os.Environment.DIRECTORY_PICTURES:android.os.Environment.DIRECTORY_DOWNLOADS),"KT-WiFi");
   if(!dir.exists()&&!dir.mkdirs())throw new Exception("폴더 생성 실패");
   try(FileOutputStream out=new FileOutputStream(new File(dir,name))){out.write(bytes);}
  }
 }
 @JavascriptInterface public void image(String data,String action){
  try{byte[] bytes=decodeImage(data);String name="KT-WiFi-"+System.currentTimeMillis()+".png";saveBytes(bytes,name,"image/png",true);notifyUser("이미지 저장 완료: 갤러리 / KT-WiFi");}
  catch(Exception e){notifyUser("이미지 저장 실패: "+e.getMessage());}
 }
 @JavascriptInterface public void promoPdf(String data,String paper){
  try{
   byte[] bytes=decodeImage(data);
   Bitmap bitmap=BitmapFactory.decodeByteArray(bytes,0,bytes.length);
   if(bitmap==null)throw new Exception("홍보물 이미지를 읽을 수 없습니다.");
   int w=595,h=842;
   if("A5".equals(paper)){w=420;h=595;}else if("A6".equals(paper)){w=298;h=420;}else if("A7".equals(paper)){w=210;h=298;}
   android.graphics.pdf.PdfDocument pdf=new android.graphics.pdf.PdfDocument();
   android.graphics.pdf.PdfDocument.PageInfo info=new android.graphics.pdf.PdfDocument.PageInfo.Builder(w,h,1).create();
   android.graphics.pdf.PdfDocument.Page page=pdf.startPage(info);
   page.getCanvas().drawColor(android.graphics.Color.WHITE);
   page.getCanvas().drawBitmap(bitmap,null,new android.graphics.Rect(0,0,w,h),new Paint(Paint.FILTER_BITMAP_FLAG));
   pdf.finishPage(page);
   java.io.ByteArrayOutputStream out=new java.io.ByteArrayOutputStream();pdf.writeTo(out);pdf.close();
   saveBytes(out.toByteArray(),"KT-Promo-"+paper+"-"+System.currentTimeMillis()+".pdf","application/pdf",false);
   notifyUser("PDF 저장 완료: 내 파일 > 다운로드 > KT-WiFi");
  }catch(Exception e){notifyUser("PDF 저장 실패: "+e.getMessage());}
 }
}
