# KT Wi-Fi QR + 홍보물 Android project

This is a **reconstructed project**, not the original Android project. Assets are extracted from the user-provided 1.6.1 APK and the promotional interface is added.

## Build
Upload the project **contents** to a GitHub repository, enable Actions, run **Build Android APK** from the Actions tab, then download the APK artifact. It is a debug APK with a new application ID, so it installs separately from the original.

## Important limitations
- Original native Bluetooth printer bridge is NOT recreated: direct Bluetooth printer connection/printing is not supported in this reconstructed build.
- OCR is reconstructed with ML Kit Latin recognition (Korean OCR is not supported by this recognizer). Korean SSIDs can be typed manually.
- PDF is not directly exported; save PNG then use a separate Print-to-PDF flow.
- Camera and file picker, image preview, QR generation, promotional PNG saving are implemented but NOT device-tested.
- Image files are saved under the app-specific Pictures directory, not DCIM/Camera.
- This is not signed for release or tested on the user's Galaxy device.
