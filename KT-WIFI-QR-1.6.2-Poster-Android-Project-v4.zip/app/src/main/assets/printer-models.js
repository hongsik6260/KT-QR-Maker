(function(){'use strict';
const models={m2h:{label:'NIIMBOT M2_H',detail:'검정·회색 본체',photo:'m2h'},b21s:{label:'NIIMBOT B21S',detail:'빨간색 본체',photo:'b21s'}};
function identify(name){const n=(name||'').toUpperCase().replace(/^NIIMBOT[ _-]*/,'');if(/^M2(?:[ _-]|$)/.test(n))return'm2h';if(/^B21S(?:[ _-]|$)/.test(n))return'b21s';return null;}
function picture(model){const span=document.createElement('span');span.className='printer-photo '+(model||'unknown');span.setAttribute('aria-hidden','true');if(model){const img=document.createElement('img');img.src='images/printers-reference.jpg';img.alt='';img.draggable=false;span.append(img);}else span.textContent='▤';return span;}
function deviceCard(device){const model=identify(device.deviceName),button=document.createElement('button');button.className='secondary device printer-device';button.append(picture(model));const text=document.createElement('span');text.className='printer-details';const title=document.createElement('strong');title.textContent=model?models[model].label:'블루투스 기기';const name=document.createElement('span');name.textContent=device.deviceName||'이름 없는 기기';text.append(title,name);button.append(text);const action=document.createElement('span');action.className='printer-action';action.textContent='연결';button.append(action);return button;}
window.PrinterModels={models,identify,picture,deviceCard};
const select=document.getElementById('btModel'),group=document.getElementById('printerModels');if(!select||!group)return;const buttons=[];
for(const [key,model]of Object.entries(models)){
 const b=document.createElement('button');b.type='button';b.className='printer-model';b.setAttribute('role','radio');b.dataset.model=key;b.append(picture(key));
 const text=document.createElement('span');text.className='printer-details';const title=document.createElement('strong');title.textContent=model.label;const detail=document.createElement('span');detail.textContent=model.detail;text.append(title,detail);b.append(text);
 const mark=document.createElement('span');mark.className='printer-action';b.append(mark);
 b.onclick=()=>{if(select.disabled)return;select.value=key;select.dispatchEvent(new Event('change',{bubbles:true}));refresh();};
 b.onkeydown=e=>{if(['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();if(!select.disabled){select.value=select.value==='m2h'?'b21s':'m2h';select.dispatchEvent(new Event('change',{bubbles:true}));refresh();buttons.find(x=>x.dataset.model===select.value).focus();}}};
 buttons.push(b);group.append(b);
}
function refresh(){for(const b of buttons){const active=b.dataset.model===select.value;b.setAttribute('aria-checked',String(active));b.tabIndex=active?0:-1;b.disabled=select.disabled;b.querySelector('.printer-action').textContent=active?'선택됨':'선택';}}
select.addEventListener('change',refresh);new MutationObserver(refresh).observe(select,{attributes:true,attributeFilter:['disabled']});refresh();
})();
