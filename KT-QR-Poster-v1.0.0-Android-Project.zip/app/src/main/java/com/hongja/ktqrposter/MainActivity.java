package com.hongja.ktqrposter;
import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.provider.MediaStore;
import android.webkit.*;
import android.widget.Toast;
import android.print.*;
import java.io.*;
import android.util.Base64;

public class MainActivity extends Activity {
 WebView web; ValueCallback<Uri[]> chooser; static final int PICK=99;
 @Override public void onCreate(Bundle state){super.onCreate(state);web=new WebView(this);setContentView(web);web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(true);web.getSettings().setAllowFileAccessFromFileURLs(true);web.getSettings().setAllowUniversalAccessFromFileURLs(false);web.addJavascriptInterface(new Bridge(),"AndroidPoster");web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> cb,FileChooserParams params){chooser=cb;try{startActivityForResult(params.createIntent(),PICK);return true;}catch(Exception e){chooser=null;return false;}}});web.loadUrl("file:///android_asset/index.html");}
 @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(req==PICK&&chooser!=null){chooser.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));chooser=null;}}
 class Bridge{
  @JavascriptInterface public void savePng(String data,String name){try{String b64=data.substring(data.indexOf(',')+1);byte[] bytes=Base64.decode(b64,Base64.DEFAULT);android.content.ContentValues cv=new android.content.ContentValues();cv.put(MediaStore.Images.Media.DISPLAY_NAME,name);cv.put(MediaStore.Images.Media.MIME_TYPE,"image/png");if(Build.VERSION.SDK_INT>=29)cv.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/KT-QR-Poster/");Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,cv);if(uri==null)throw new IOException("Cannot create image");try(OutputStream out=getContentResolver().openOutputStream(uri)){out.write(bytes);}runOnUiThread(()->Toast.makeText(MainActivity.this,"PNG 저장 완료: 사진/KT-QR-Poster",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(MainActivity.this,"PNG 저장 실패: "+e.getMessage(),Toast.LENGTH_LONG).show());}}
  @JavascriptInterface public void printPoster(){runOnUiThread(()->{PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE);pm.print("KT QR Poster",web.createPrintDocumentAdapter("KT QR Poster"),new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setColorMode(PrintAttributes.COLOR_MODE_COLOR).build());});}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
}
